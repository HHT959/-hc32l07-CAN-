#include "config.h"

unsigned char disp_buf[5];

const unsigned char LEDTABLE[]={NUM0,NUM1,NUM2,NUM3,NUM4,NUM5,NUM6,NUM7,NUM8,NUM9,SEGC_E,SEGC_A,SEGC_O,SEGC_L,SEGC_P,DARK};

void swap(unsigned char *pt)
{
	unsigned char ctemp1,ctemp2;
	ctemp1 = *pt;
	ctemp2 = *pt;
	ctemp1 =ctemp1>>4;
	ctemp2 =ctemp2<<4;
	*pt =ctemp1|ctemp2;
}
void BCDTOINT(unsigned int *dt,unsigned char *pdisp,unsigned char len)
{
	unsigned char i;
	unsigned int itemp=0;
	for(i=0;i<len;i++)
		itemp = itemp*10 + (*(pdisp+len-1-i) & 0x0f);
	*dt = itemp;	
}
void INTTOBCD(unsigned int dt,unsigned char *pdisp,unsigned char len,unsigned char Blank)
{
	unsigned char i;
	unsigned char ctemp;
	for(i=0;i<len;i++)
		*(pdisp+i) =0x0F;
	for(i=0;i<len;i++){
		ctemp = dt%10;
		if((ctemp==0) && Blank){		//����������
			if(i&&(dt==0))break;
		}
		*(pdisp+i) = ctemp;
		dt = dt/10;
	}
}
void DispInt(unsigned int itemp)
{
	INTTOBCD(itemp,&disp_buf[0],5,1);
	disp_ram[7]=LEDTABLE[disp_buf[4]];
	disp_ram[6]=LEDTABLE[disp_buf[3]];
	disp_ram[5]=LEDTABLE[disp_buf[2]];
	disp_ram[3]=LEDTABLE[disp_buf[1]];
	disp_ram[2]=LEDTABLE[disp_buf[0]];
}

void DispError(unsigned char ErrNum)
{
	if(ErrNum & PS_ERR_SHIELD){
		disp_ram[6] = SEGC_E; 
		disp_ram[5] = SEGC_R; 
		disp_ram[3]	= SEGC_R;		
		disp_ram[2] = NUM1;	
		LCDFlagOn(LF_PS1C);
	}
	else if(ErrNum & FS_ERR){
		disp_ram[6] = SEGC_E; 
		disp_ram[5] = SEGC_R; 
		disp_ram[3]	= SEGC_R;	
		disp_ram[2] = NUM3;
		LCDFlagOn(LF_LEV);
		LCDFlagOn(LF_PS2C);
	}
	else if(ErrNum & OPEN_ERR){
		disp_ram[6] = SEGC_E; 
		disp_ram[5] = SEGC_R; 
		disp_ram[3]	= SEGC_R;	
		disp_ram[2] = NUM5;
		if(MS_TT)LCDFlagOn(LF_MOTOR);
	}
	else if(ErrNum & SHORT_ERR){
		disp_ram[6] = SEGC_E; 
		disp_ram[5] = SEGC_R; 
		disp_ram[3]	= SEGC_R;	
		disp_ram[2] = NUM4;
		if(MS_TT)LCDFlagOn(LF_MOTOR);	
	}
}
void DispRest(struct TIME strTime)
{
	if(strTime.Second>0){
		strTime.Minute ++;
		if(strTime.Minute>=60) {
			strTime.Minute =0;
			if(strTime.Hour<99)strTime.Hour++;
		}
	}
	INTTOBCD(strTime.Hour,&disp_buf[3],2,1);
	disp_ram[7] = 0;
	disp_ram[6] = LEDTABLE[disp_buf[4]];
	disp_ram[5] = LEDTABLE[disp_buf[3]];
	
	INTTOBCD(strTime.Minute,&disp_buf[0],2,1);
	if(disp_buf[1] ==0x0f) disp_buf[1]=0;
	disp_ram[3]=LEDTABLE[disp_buf[1]];
	disp_ram[2]=LEDTABLE[disp_buf[0]];
	
	LCDFlagOn(LF_REST);
	LCDFlagOn(LF_MINU);
	if(MS_TT)
		LCDFlagOn(LF_DP);
	else
		LCDFlagOff(LF_DP);
}
void SetProg(void)
{
	switch(SetMode){
		case 1:
			INTTOBCD(RunTime,&disp_buf[0],4,0);
			disp_ram[6]=LEDTABLE[disp_buf[3]];
			disp_ram[5]=LEDTABLE[disp_buf[2]];
			disp_ram[3]=LEDTABLE[disp_buf[1]];
			disp_ram[2]=LEDTABLE[disp_buf[0]];
			switch(Index){
				case 0:
					if(MS_TT==0) disp_ram[2] =0;
					break;
				case 1:
					if(MS_TT==0) disp_ram[3] =0;
					break;
				case 2:
					if(MS_TT==0) disp_ram[5] =0;
					break;
				case 3:
					if(MS_TT==0) disp_ram[6] =0;
					break;
			}
			LCDFlagOn(LF_SEC);
			LCDFlagOn(LF_WORK);
			LCDFlagOn(LF_SET);
			break;
		case 2:
			INTTOBCD(StopTime.Hour,&disp_buf[3],2,0);
			disp_ram[6] = LEDTABLE[disp_buf[4]];
			disp_ram[5] =LEDTABLE[disp_buf[3]];
			INTTOBCD(StopTime.Minute,&disp_buf[0],2,0);
			if(disp_buf[1] ==0x0f) disp_buf[1]=0;
			disp_ram[3]=LEDTABLE[disp_buf[1]];
			disp_ram[2]=LEDTABLE[disp_buf[0]];	
			switch(Index){
				case 0:
					if(MS_TT==0) disp_ram[2] =0;
					break;
				case 1:
					if(MS_TT==0) disp_ram[3] =0;
					break;
				case 2:
					if(MS_TT==0) disp_ram[5] =0;
					break;
				case 3:
					if(MS_TT==0) disp_ram[6] =0;
					break;
			}
			LCDFlagOn(LF_DP);
			LCDFlagOn(LF_REST);
			LCDFlagOn(LF_SET);
			LCDFlagOn(LF_MINU);
			break;
	}
}

void LCDDisplay(void)
{
	unsigned char i;
	for(i=0;i<12;i++)  disp_ram[i]=0;
	switch(Work_Status){
		case Rest_stat:				//��ֹ
			DispRest(WorkTime);
			LCDFlagOn(LF_MINU);
			LCDFlagOn(LF_REST);
			break;
		case Work_stat:			//����
			DispInt(RWorkTime);
			LCDFlagOn(LF_SEC);
			LCDFlagOn(LF_WORK);
			LCDFlagOn(LF_LED);
			LCDFlagOn(LF_MOTOR);
			if(HandRest_T) LCDFlagOn(LF_HAND);
			break;
		case Hand_stat:			//�ֶ�
			DispInt(ForceTime);
			LCDFlagOn(LF_SEC);
			LCDFlagOn(LF_HAND);
			LCDFlagOn(LF_LED);
			LCDFlagOn(LF_MOTOR);
			break;
		case Set_stat:				//����
			SetProg();	
			break;
		case Error_stat:				//����
			DispError(ErrorFlag);
			break;
		case Look_stat:				//����������ѯ
			DispInt(WorkTimeCnt);
			LCDFlagOn(LF_TIME);
			LCDFlagOn(LF_WORK);
			break;
	}
	if(PSstat || (ErrorFlag & PS_ERR_SHIELD) ){
		LCDFlagOn(LF_PS1);
	}
	else{
		LCDFlagOff(LF_PS1);
	}
	
	if(FSstat){
		LCDFlagOn(LF_PS2);
	}
	else{
		LCDFlagOff(LF_PS2);
	}
	
	if(bSave){
		LCDFlagOn(LF_CELL);
	}
	else{
		LCDFlagOff(LF_CELL);
	}
}

