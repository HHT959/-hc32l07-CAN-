#ifndef __DISPLAY_H_
#define __DISPLAY_H_

extern unsigned char disp_buf[5];

void swap(unsigned char *pt);
void BCDTOINT(unsigned int *dt,unsigned char *pdisp,unsigned char len);
void INTTOBCD(unsigned int dt,unsigned char *pdisp,unsigned char len,unsigned char Blank);
void DispInt(unsigned int itemp);
void DispError(unsigned char ErrNum);
void SetProg(void);
void LCDDisplay(void);

#endif

