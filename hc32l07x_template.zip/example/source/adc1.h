#ifndef __ADC1_H
#define __ADC1_H

#define TEMPERIN	1
#define VOLTIN		2
#define CURRENTIN	0

extern signed char Temper;
extern unsigned int Voltage;
extern unsigned int Current;
extern unsigned char CurrentFinish;

unsigned int GetADValue(unsigned char ch);
void ReadTemper(void);
void ReadCurrent(void);
void ReadVoltage(void);

#endif 

