#ifndef __INIT_H
#define __INIT_H

void InitMCU(void);

#endif 
