#include "config.h"

unsigned char NoKey_JS;
unsigned char KeyMode;
unsigned char Key_JSQ;
unsigned char SetMode;

unsigned char Index;
unsigned char LockCnt;
unsigned char LockTime;
enum WORKSTATUS Bak_Work_Status;	

void DO_KEY_INCLP(void)   //�Ӽ�����
{
	if(LockFlag & LOCK)return;
	if(ErrorFlag||RUN_STOP_T) return;
	LookTime =CONSTLOOKTIME;
	Work_Status =Look_stat;
	BELLON(1,BUZZTIME);
}
void DO_KEY_INC(void)
{
	unsigned char ctemp;
	BELLON(1,BUZZTIME);
	switch(SetMode){
		case 1:
			switch(Index){
				case 0:
					ctemp = RunTime%10 ;
					if(ctemp<9)
						RunTime = RunTime+1;
					else 
						RunTime = RunTime-9;
					break;
				case 1:
					ctemp = (RunTime/10)%10 ;
					if(ctemp<9)
						RunTime = RunTime+10;
					else 
						RunTime = RunTime-90;
					break;
				case 2:
					ctemp = (RunTime/100)%10 ;
					if(ctemp<9)
						RunTime = RunTime+100;
					else 
						RunTime = RunTime-900;
					break;
				case 3:
					ctemp = (RunTime/1000)%10 ;
					if(ctemp<9)
						RunTime = RunTime+1000;
					else 
						RunTime = RunTime-9000;
					break;
			}
			break;
		case 2:
			switch(Index){
				case 0:
					ctemp = StopTime.Minute%10 ;
					if(ctemp<9)
						StopTime.Minute++;
					else 
						StopTime.Minute=StopTime.Minute-9;
					break;
				case 1:
					ctemp = (StopTime.Minute/10)%10 ;
					if(ctemp<5)
						StopTime.Minute =StopTime.Minute+10;
					else 
						StopTime.Minute=StopTime.Minute-50;
					break;
				case 2:
					ctemp = StopTime.Hour%10 ;
					if(ctemp<9)
						StopTime.Hour++;
					else 
						StopTime.Hour=StopTime.Hour-9;
					break;
				case 3:
					ctemp = (StopTime.Hour/10)%10 ;
					if(ctemp<9)
						StopTime.Hour=StopTime.Hour+10;
					else 
						StopTime.Hour=StopTime.Hour-90;
					break;
			}
			break;
	}
}
void DO_KEY_MOV(void)
{
//	unsigned char i;
	if(SetMode){
		BELLON(1,BUZZTIME);
		switch (SetMode){
			case 1:
				if(++Index>=4) Index =0;
				break;
			case 2:
				if(++Index>=4) Index =0;
				break;
		}
	}
	else{
		if(RUN_STOP_T==0){
			LockCnt++;
			LockTime=4;
			if(LockCnt>=10){
				LockCnt=0;
				BELLON(1,BUZZTIME);
				LockFlag=LockFlag^LOCK;
				WritePara(LOCK_ADDR,(unsigned int *)(&LockFlag),sizeof(LockFlag));
			}	
		}
	}
}
void DO_KEY_SETIN(void)
{
	if((LockFlag&LOCK)==LOCK)return;
	if(SetMode==0){
		Bak_Work_Status = Work_Status;
	}
	SetMode = 1;
	WRLYOFF();
	BELLON(1,BUZZTIME);
	RUN_STOP_T = 0;
	Index =0;
	Work_Status =Set_stat;
}
void DO_KEY_SET(void)
{	
//	unsigned char i;
	if((LockFlag&LOCK)==LOCK)return;
	BELLON(1,BUZZTIME);
	if(++SetMode>2) SetMode =0;
	Index =0;
	switch(SetMode){
		case 1:
			break;
		case 2:
			StopTime.Second =0;
			break;
		case 0:
			SaveSetValue();
			ErrorFlag =0;
			//Send_SetPara();
			StartWork();
			break;
	}
}
void DO_KEY_RST(void)
{
	if(SetMode==0){
		BELLON(1,BUZZTIME);
		if(ErrorFlag){
			ErrorFlag =0;
			WritePara(ALM_STATUS_ADDR,(unsigned int *)(&ErrorFlag),sizeof(ErrorFlag));
		}
		if(RUN_STOP_T==0){
			Force_Work_T = 0;
			HandRest_T =1;
			StartWork();
		}
		else {
			StopWork();
		}
	}
	else{
		DO_KEY_SETIN();
	}
}
void DO_WORK_RST(void)
{
	if(SetMode ==0){
		BELLON(1,BUZZTIME);
		if(ErrorFlag){
			ErrorFlag =0;
			WritePara(ALM_STATUS_ADDR,(unsigned int *)(&ErrorFlag),sizeof(ErrorFlag));
		}
		Force_Work_T = 0;
		StopWork();
	}
}
void DO_ForceWork(void)
{
	if(SetMode==0){
		BELLON(1,BUZZTIME);
		Force_Work_T = 1;
		ForceTime =0;
		WRLYON();
		Work_Status =Hand_stat;
	}
}
void DO_KEY_NOKEY(void)
{
	if(SetMode){		//�����˳�
		SetMode = 0;		
		BELLON(1,BUZZTIME);
		ReadSetValue();
		Work_Status = Bak_Work_Status ;
		//StartWork();
	}
}
unsigned char KeyScan(void)
{
	unsigned char tt;
	tt = Gpio_GetInputData(GpioPortB) & (0x78); 
	tt |= (~0x78);
	tt = ~tt;
	if(RSTIN()==0) tt|=KEYRST;
	return(tt);
}
//��������
void KEY_CNT(void)
{
	unsigned char KeyNum;
//	static unsigned char KeyBuf=0;
	static unsigned char Key_JSQ=0;
	KeyNum = KeyScan();
	if(KeyNum&&(LookTime==0)){
		//�����պ�
		NoKey_JS = 0;
		LedLightTime =BACKLIGHTTIME;
		BKLED_ON();
//		KeyBuf=KeyNum;
		if(Key_JSQ<255)Key_JSQ++;
		switch (KeyMode){
			case 0:							//�޻�״̬
				if(Key_JSQ>=AN_XD_DL){		//�����պϼ�ʱ��>����ʱ��
					Key_JSQ = 0;
					switch (KeyNum){
						case KEYSET:
							if(SetMode){
								DO_KEY_SET();
								KeyMode = 3;
							}
							else{
								KeyMode = 1;
							}
							break;
						case KEYMOV:
							DO_KEY_MOV();
							KeyMode = 3;
							break;
						case KEYINC:
							if(SetMode){
								DO_KEY_INC();
								KeyMode = 3;
							}
							else{
								KeyMode = 1;
							}
							break;
						case KEYRST:
							if(ErrorFlag){
								DO_KEY_RST();
								KeyMode = 3;
							}
							else{
								if(RUN_STOP_T==0){
									KeyMode = 2;		
								}
								else{
									DO_KEY_RST();
									KeyMode = 3;
								}
							}
							break;
					}			
				}
				break;
			case 1:	
				if(KeyNum==KEYSET){
					if(Key_JSQ>=AN_CJ_DL){		 
						DO_KEY_SETIN();			 
						KeyMode = 3;			 
					}
				}
				if(KeyNum==KEYINC){
					if(Key_JSQ>=AN_CJ_DL){	
						DO_KEY_INCLP();			
						KeyMode = 3;			 	
					}
				}
				break;
			case 2:
				if(KeyNum==KEYRST){
					if(Key_JSQ>=AN_1S_DL){
						DO_KEY_RST();		
						KeyMode = 3;
					}
				}
				break;
			default:
				break;
		}
	}
	else{
			/*
		 if(KeyBuf==KEYRST){	
			 if(KeyMode==2){
				DO_KEY_RST();
			 }
			 else if(KeyMode==4){
				DO_WORK_RST();	//��λ
			 } 
		 }
		 */
		 KeyMode = 0;
		 Key_JSQ = 0;
		 if(NoKey_JS>=AN_NO_DL){
			//�޻�
			DO_KEY_NOKEY();
		 }
	}	
}
