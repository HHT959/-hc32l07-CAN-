#ifndef __LEDTABLE_H_
#define __LEDTABLE_H_
//��ʾ������
//0x80��˸; 0x40����; 0x20�ر�;0x10С����
#define DSP_CLOSE        0x20
#define DSP_NONE         0x40
#define DSP_BLINK        0x80
#define DSP_DOT          0x10
#define DSP_RESET        0x00

#define SEGA			0x80
#define	SEGB			0x20
#define SEGC			0x40
#define SEGD			0x10
#define SEGE			0x01
#define	SEGF			0x02
#define	SEGG			0x04
#define SEGP			0x08
#define DARK			0x00

#define NUM0		SEGA|SEGB|SEGC|SEGD|SEGE|SEGF
#define NUM1		SEGB|SEGC
#define NUM2		SEGA|SEGB|SEGD|SEGE|SEGG
#define NUM3		SEGA|SEGB|SEGC|SEGD|SEGG
#define NUM4		SEGB|SEGC|SEGF|SEGG
#define NUM5		SEGA|SEGC|SEGD|SEGF|SEGG
#define NUM6		SEGA|SEGC|SEGD|SEGE|SEGF|SEGG
#define NUM7		SEGA|SEGB|SEGC
#define NUM8		SEGA|SEGB|SEGC|SEGD|SEGE|SEGF|SEGG
#define NUM9		SEGA|SEGB|SEGC|SEGD|SEGF|SEGG

#define SEGC_E		SEGA|SEGD|SEGE|SEGF|SEGG
#define SEGC_A		SEGA|SEGB|SEGC|SEGE|SEGF|SEGG
#define SEGC_O		SEGA|SEGB|SEGC|SEGD|SEGE|SEGF
#define SEGC_L		SEGD|SEGE|SEGF
#define SEGC_P		SEGA|SEGB|SEGE|SEGF|SEGG
#define SEGC_D		SEGB|SEGC|SEGD|SEGE|SEGG
#define SEGC_B		SEGC|SEGD|SEGE|SEGF|SEGG
#define SEGC_R		SEGE|SEGG

#define NUME		10
#define NUMA		11
#define NUMO		12
#define NUML		13
#define NUMP		14

#define LF_HAND		0,0x80						//�ֶ�
#define LF_REST		0,0x08						//��ֹ
#define LF_SET		1,0x08						//����
#define LF_DP			1,0x02						//����
#define LF_WORK		1,0x80			      //����
#define LF_TIME		1,0x10			      //��
#define LF_MINU		1,0x20			      //����
#define LF_SEC		1,0x40			      //��
#define LF_MOTOR	0,0x20						//���
#define LF_LED		0,0x40						//LED
#define LF_PS1		0,0x02						//PS1
#define LF_PS2		0,0x10						//PS2
#define LF_CELL		0,0x04						//���
#define LF_LEV		1,0x04						//Һλ
#define LF_PS1C		0,0x01						//PS1�ַ�
#define LF_PS2C		1,0x01						//PS2�ַ�

#endif

