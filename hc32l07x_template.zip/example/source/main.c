/******************************************************************************
* Copyright (C) 2019, Huada Semiconductor Co.,Ltd All rights reserved.
*
* This software is owned and published by:
* Huada Semiconductor Co.,Ltd ("HDSC").
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with HDSC
* components. This software is licensed by HDSC to be adapted only
* for use in systems utilizing HDSC components. HDSC shall not be
* responsible for misuse or illegal use of this software for devices not
* supported herein. HDSC is providing this software "AS IS" and will
* not be responsible for issues arising from incorrect user implementation
* of the software.
*
* Disclaimer:
* HDSC MAKES NO WARRANTY, EXPRESS OR IMPLIED, ARISING BY LAW OR OTHERWISE,
* REGARDING THE SOFTWARE (INCLUDING ANY ACOOMPANYING WRITTEN MATERIALS),
* ITS PERFORMANCE OR SUITABILITY FOR YOUR INTENDED USE, INCLUDING,
* WITHOUT LIMITATION, THE IMPLIED WARRANTY OF MERCHANTABILITY, THE IMPLIED
* WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE OR USE, AND THE IMPLIED
* WARRANTY OF NONINFRINGEMENT.
* HDSC SHALL HAVE NO LIABILITY (WHETHER IN CONTRACT, WARRANTY, TORT,
* NEGLIGENCE OR OTHERWISE) FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT
* LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION,
* LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING FROM USE OR
* INABILITY TO USE THE SOFTWARE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA,
* SAVINGS OR PROFITS,
* EVEN IF Disclaimer HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THE SOFTWARE TO ACHIEVE YOUR
* INTENDED RESULTS, AND FOR THE INSTALLATION OF, USE OF, AND RESULTS OBTAINED
* FROM, THE SOFTWARE.
*
* This software may be replicated in part or whole for the licensed use,
* with the restriction that this Disclaimer and Copyright notice must be
* included with each copy of this software, whether used in part or whole,
* at all times.
*/
/******************************************************************************/
/** \file main.c
 **
 ** A detailed description is available at
 ** @link Sample Group Some description @endlink
 **
 **   - 2019-03-01  1.0  Lux First version
 **
 ******************************************************************************/

/******************************************************************************
 * Include files
 ******************************************************************************/

#include "config.h"
void SelfTest(void);
void delaynms(unsigned char dly);
void DS1S_CNT(void);
void DS500MS_CNT(void);
void DS100MS_CNT(void);
void DS10MS_CNT(void);
void initpara(void);
void PowerFailure(void);	//�ϵ籣������
void PSProg(void);
void FSProg(void);
void CurrentHelpProg(void);

unsigned char MS_TT;
unsigned char JS10MS_T;
unsigned char MS250_TT;
unsigned char JS300MS_T;
unsigned char JS500MS_T;
unsigned char JS1S_T;
unsigned int RUN_STOP_T;
unsigned char Force_Work_T;
unsigned int ForceTime;

unsigned int ErrorFlag;

unsigned int LockFlag;
unsigned char LookTime;
unsigned int RunTime;			//�趨����ʱ��
unsigned int RWorkTime;			//����ʱ��
unsigned int WorkTimeCnt;		//������������

struct TIME StopTime;
struct TIME WorkTime;

unsigned char ucMin;		//��ֹʱ����Ӷ�ʱ

unsigned char beeptime;
unsigned char BeepCnt;
unsigned char BeepTime;

unsigned char LedLightTime;
unsigned int ErrDly;

enum WORKSTATUS Work_Status;	//0:��ֹ��1��������2���ֶ�������3������״̬��4�����ϣ�5������������ѯ

unsigned char cTimeOut;
unsigned char ucMin;
unsigned char WorkStep;
unsigned char PSstat;
unsigned char FSstat;
unsigned char Force_T;
unsigned int WorkVoltage;
unsigned char HandRest_T;
unsigned char bSave;

unsigned char Rec_OK=0;  
unsigned char RecBuf[8];

unsigned char Can_TX_Flag=0;


void CAN_Receive_Deal(void)
{
	unsigned int itemp;
	unsigned int itemp_dt;
	unsigned char dt;
	if(Rec_OK){
		Rec_OK =0;	
		if(RecBuf[2]&0x08){		//��������
			itemp = RecBuf[0]+((unsigned int)RecBuf[1]<<8); 
			itemp_dt = RecBuf[6]+((unsigned int)RecBuf[7]<<8); 
			switch(itemp){
				case 1:						//��������ʱ�����
					if(itemp_dt<=16){
						dt = RunTime%MINTIME;
						RunTime = itemp_dt * MINTIME + dt;
						if(RunTime==0){
							ReadPara(RUN_ADDRESS,(unsigned int*)(&RunTime),sizeof(RunTime));
						}
						else{
							WritePara(RUN_ADDRESS,(unsigned int*)(&RunTime),sizeof(RunTime));
						}
					}
				break;
				case 2:						//��������ʱ����
					if(itemp_dt<=59){
						dt = RunTime/MINTIME;
						RunTime = itemp_dt + dt*MINTIME;
						if(RunTime==0){
							ReadPara(RUN_ADDRESS,(unsigned int*)(&RunTime),sizeof(RunTime));
						}
						else{
							WritePara(RUN_ADDRESS,(unsigned int*)(&RunTime),sizeof(RunTime));
						}
					}
				break;
				case 3:						//������ֹʱ��Сʱ
					if(itemp_dt<=99){			
						if(itemp_dt || StopTime.Minute){
							StopTime.Hour = itemp_dt;
							WritePara(STOP_ADDRESS,(unsigned int*)(&StopTime),sizeof(StopTime));
						}
					}
					if(RUN_STOP_T==0){
						WorkTime = StopTime;
					}
				break;	
				case 4:							//������ֹʱ�����
					if(itemp_dt<=59){
						if(itemp_dt || StopTime.Hour){
							StopTime.Minute = itemp_dt;
							WritePara(STOP_ADDRESS,(unsigned int*)(&StopTime),sizeof(StopTime));
						}
					}
					if(RUN_STOP_T==0){
						WorkTime = StopTime;
					}
				break;
				case 5:
					if(itemp_dt==1){    //�ֶ�����
						if(ErrorFlag){
							ErrorFlag =0;
							WritePara(ALM_STATUS_ADDR,(unsigned int*)(&ErrorFlag),sizeof(ErrorFlag));
						}
						HandRest_T =1;
						StartWork();
					}
					else if(itemp_dt==0){		//�Զ���
						if(ErrorFlag){
							ErrorFlag =0;
							WritePara(ALM_STATUS_ADDR,(unsigned int*)(&ErrorFlag),sizeof(ErrorFlag));
						}
						RUN_STOP_T = 0;
						WRLYOFF();
						Work_Status =Rest_stat;
						HandRest_T =0;
						PSstat =0;
					}
				break;
			}
			Send_SetPara();
		}
	}
}
void FSProg(void)
{
	static unsigned char ywcnt=0; 
	if(RUN_STOP_T==0) return;
	if(FSIN()==0){
		if(++ywcnt>=2){
			ywcnt = 0;
	   	FSstat = 1;
			if((ErrorFlag & FS_ERR)==0){
				BELLON(10,ERRBUZZTIME);
				LedLightTime =BACKLIGHTTIME;
				ErrDly = CONSTERRDLYTIME;
				HandRest_T =0;
			}
			ErrorFlag |= FS_ERR;
			RUN_STOP_T= 0;
			WRLYOFF();
			Work_Status = Error_stat;
		}
	}
	else{
		FSstat = 0;
	}
}
void PSProg(void)
{
	static unsigned char ylcnt[5]={128,128,128,128,128};
	if(PS1IN()==0){
		if(++ylcnt[0]>=(128+2)){
			ylcnt[0]=130;
			PSstat |=0x08;
		}
	}
	else{
		if(--ylcnt[0]<=(128-2)){
			ylcnt[0]=126;
		}
	}
	if(PS2IN()==0){
		if(++ylcnt[1]>=(128+2)){
			ylcnt[1]=130;
			PSstat |=0x10;
		}
	}
	else{
		if(--ylcnt[1]<=(128-2)){
			ylcnt[1]=126;
		}
	}
	if(PS3IN()==0){
		if(++ylcnt[2]>=(128+2)){
			ylcnt[2]=130;
			PSstat |=0x20;
		}
	}
	else{
		if(--ylcnt[2]<=(128-2)){
			ylcnt[2]=126;
		}
	}
	if(PS4IN()==0){
		if(++ylcnt[3]>=(128+2)){
			ylcnt[3]=130;
			PSstat |=0x40;
		}
	}
	else{
		if(--ylcnt[3]<=(128-2)){
			ylcnt[3]=126;
		}
	}
	if(PS5IN()==0){
		if(++ylcnt[4]>=(128+2)){
			ylcnt[4]=130;
			PSstat |=0x80;
		}
	}
	else{
		if(--ylcnt[4]<=(128-2)){
			ylcnt[4]=126;
		}
	}
}

void PowerFailure(void)
{
	unsigned int itemp;
	itemp =GetADValue(VOLTIN);
	if(itemp <=200){
		if(bSave==0){
			if(HandRest_T){
				RUN_STOP_T =0;
			}
			WritePara(WORK_ADDRESS,(unsigned int*)(&WorkTime),sizeof(WorkTime));
			WritePara(RUN_STOP_ADDR,(unsigned int*)(&RUN_STOP_T),sizeof(RUN_STOP_T));
			bSave=1;
		}
	}
	else{
		bSave=0;
	}	
}

void ReadWorkVoltage(void)
{
	WorkVoltage = GetADValue(VOLTIN);
}
/**
 ******************************************************************************
 ** \brief  Main function of project
 **
 ** \return uint32_t return value, if needed
 **
 ******************************************************************************/
int32_t main(void)
{
	InitMCU();			
	ReadWorkVoltage();	
	initpara();
	Wdt_Start();						///< ���� WDT
	while (1){
		DS10MS_CNT();
		DS100MS_CNT();
		DS500MS_CNT();
		DS1S_CNT();
		Wdt_Feed();   // ι��	//�忴�Ź�
		PowerFailure();
	}
}

void initpara(void)
{
	unsigned int checksum;
	
	ReadPara(CHECK_ADDRESS,(unsigned int*)(&checksum),sizeof(checksum));		
	if(checksum != 0x55AA){
		checksum = 0x55AA;
		StopTime.Hour = 24;
		StopTime.Minute =0;
		StopTime.Second =0;
		WorkTime = StopTime;
		RUN_STOP_T =0;
		WorkTimeCnt =0;
		RunTime =5;
		LockFlag =0;		
		
		WritePara(CHECK_ADDRESS,(unsigned int*)(&checksum),sizeof(checksum));
		WritePara(RUN_ADDRESS,(unsigned int*)(&RunTime),sizeof(RunTime));
		WritePara(STOP_ADDRESS,(unsigned int*)(&StopTime),sizeof(StopTime));
		WritePara(WORK_ADDRESS,(unsigned int*)(&WorkTime),sizeof(WorkTime));
		WritePara(RUN_STOP_ADDR,(unsigned int*)(&RUN_STOP_T),sizeof(RUN_STOP_T));	
		WritePara(ALM_STATUS_ADDR,(unsigned int*)(&ErrorFlag),sizeof(ErrorFlag));
		WritePara(LOCK_ADDR,(unsigned int*)(&LockFlag),sizeof(LockFlag));
		WritePara(WORK_CONT_ADDR,(unsigned int*)(&WorkTimeCnt),sizeof(WorkTimeCnt));	

	}
	else{
		
		ReadPara(RUN_ADDRESS,(unsigned int*)(&RunTime),sizeof(RunTime));	
		ReadPara(STOP_ADDRESS,(unsigned int*)(&StopTime),sizeof(StopTime));
		ReadPara(WORK_ADDRESS,(unsigned int*)(&WorkTime),sizeof(WorkTime));
		ReadPara(RUN_STOP_ADDR,(unsigned int*)(&RUN_STOP_T),sizeof(RUN_STOP_T));
		ReadPara(WORK_CONT_ADDR,(unsigned int*)(&WorkTimeCnt),sizeof(WorkTimeCnt));
		ReadPara(ALM_STATUS_ADDR,(unsigned int*)(&ErrorFlag),sizeof(ErrorFlag));
		ReadPara(LOCK_ADDR,(unsigned int*)(&LockFlag),sizeof(LockFlag));
		
	}

	if(StopTime.Hour == 0 && StopTime.Minute == 0 && StopTime.Second == 0 ){
		StopTime.Hour =10;
		StopTime.Minute = 0;
		StopTime.Second = 0;
		WritePara(STOP_ADDRESS,(unsigned int*)(&StopTime),sizeof(StopTime));
	}		
	if(ErrorFlag==0){
		if(RUN_STOP_T){
			StartWork();
		}
		else{
			if(WorkTime.Hour>StopTime.Hour)WorkTime = StopTime;
			Work_Status =Rest_stat;
		}
	}
	else{
		Work_Status = Error_stat;
	}
	BELLON(1,BUZZTIME);
}

void ReadSetValue(void)
{
	ReadPara(RUN_ADDRESS,(unsigned int*)(&RunTime),sizeof(RunTime));
	ReadPara(STOP_ADDRESS,(unsigned int*)(&StopTime),sizeof(StopTime));
}

void SaveSetValue(void)
{
	if(RunTime){
		WritePara(RUN_ADDRESS,(unsigned int*)(&RunTime),sizeof(RunTime));
	}
	else{
		ReadPara(RUN_ADDRESS,(unsigned int*)(&RunTime),sizeof(RunTime));
	}
	if(StopTime.Hour == 0 && StopTime.Minute == 0 && StopTime.Second == 0){
		ReadPara(STOP_ADDRESS,(unsigned int*)(&StopTime),sizeof(StopTime));
	}
	else{
		WritePara(STOP_ADDRESS,(unsigned int*)(&StopTime),sizeof(StopTime));
	}
}

void BELL_Prog(void)
{
	if(beeptime==0){
		if(BeepCnt){
			BeepCnt--;
			beeptime = BeepTime;		//��������
		}
	}
}

void BELLON(unsigned char Bellcnt,unsigned char Belltime)
{
	BeepCnt = Bellcnt-1;		//�������еĴ���
	BeepTime = Belltime;		//���η������е�ʱ��
	beeptime = BeepTime;		//��������
}

void delaynms(unsigned char dly)
{
	cTimeOut=dly;
	while(cTimeOut)	Wdt_Feed();   // ι��	//�忴�Ź�
}

void DS1S_CNT(void)
{	
	//unsigned char t[8];
	if(JS1S_T){
		JS1S_T = 0;
		if(NoKey_JS<255)NoKey_JS ++;
		if(LockTime)LockTime--;
		else LockCnt=0;
		BELL_Prog();
		WorkProc();	
		if(LedLightTime){
			LedLightTime--;
			BKLED_ON();
		}
		else{
			BKLED_OFF();
			if(ErrorFlag){
				if(ErrDly){
					ErrDly --;
				}
				else{
					LedLightTime = BACKLIGHTTIME;
					ErrDly =CONSTERRDLYTIME;
				}
			}
		}
		
		if(ErrorFlag){
			BELLON(1,50);
			ERLYON();
		}
		else{
			ERLYOFF();
		}
		CAN_Deal();
		delaynms(1);
		Send_SetPara();	
		//delaynms(1);
		//Send_Print();
		
//		WorkVoltage = GetADValue(VOLTIN);
//		t[0] =(unsigned char)(WorkVoltage>>8);
//		t[1] =(unsigned char)(WorkVoltage);
////		t[0] =(unsigned char)(Current>>8);
////		t[1] =(unsigned char)(Current);
//		t[2] = 0x00;
//		t[3] = 0x00;
//		t[4] = 0x00;		//�Զ���
//		t[5] = 0x00;
//		t[6] = 0x00;
//		t[7] = 0x00;
//		CAN_Transmit_Data(0x234,t, 8);	/* �������� */
	}
}

void DS500MS_CNT(void)
{	
	if(JS500MS_T){
	    JS500MS_T = 0;
		//500ms��������
		MS_TT =!MS_TT;
		LCDDisplay();
		Senddisp_ram();
	}
}

void DS100MS_CNT(void)
{	
	if(JS300MS_T){
	    JS300MS_T = 0;
		//300ms��������
		if(LookTime){
			LookTime--;
			if((Work_Status ==Look_stat) && LookTime==0){
				Work_Status = Rest_stat ;
			}
		}
		ReadTemper();
		ReadCurrent();
		CurrentHelpProg();
	}
}
void DS10MS_CNT(void)
{
	static unsigned char JSQ_500MS=0;
	static unsigned char JSQ_300MS=0;
	static unsigned char JSQ_250MS=0;
	static unsigned char JSQ_1S=0;
	if(JS10MS_T){
	    JS10MS_T = 0;
		//10ms��������
		PSProg();
		FSProg();
		KEY_CNT();
		CAN_Receive_Deal();
		if(++JSQ_500MS>=50){
			JSQ_500MS=0;
			JS500MS_T=1;
		} 
		if(++JSQ_300MS>=10){
			JSQ_300MS=0;
			JS300MS_T=1;
		}
		if(++JSQ_1S>=100){
			JSQ_1S=0;
			JS1S_T=1;
		} 
		if(++JSQ_250MS>=25){
			JSQ_250MS =0;
			MS250_TT = !MS250_TT;
		}
	}
}

void CurrentHelpProg(void)
{	
	static unsigned char OverCurrentCnt=0; 
	static unsigned char UnderCurrentCnt=0; 
	//unsigned int itemp;
	if(RUN_STOP_T && CurrentFinish){
		CurrentFinish =0;
//		itemp = GetADValue(CURRENTIN);
		if(WorkVoltage<DC18V){		//���빤����ѹΪ18V����
			if(Current < DC12V_LOW){
				OverCurrentCnt = 0;
				if(++UnderCurrentCnt>OVERCURRTIME){
					UnderCurrentCnt =0;
					LedLightTime =BKLTIME;
					BKLED_ON();
					ErrorFlag = OPEN_ERR;
					WritePara(ALM_STATUS_ADDR,(unsigned int*)(&ErrorFlag),sizeof(ErrorFlag));
					StopWork();
					Work_Status  = Error_stat;
					LedLightTime = BACKLIGHTTIME;
					ErrDly =CONSTERRDLYTIME;
					BELLON(10,ERRBUZZTIME);
				}
			}
			else if(Current > DC12V_HIGH){
				UnderCurrentCnt = 0;
				if(++OverCurrentCnt>OVERCURRTIME){
					OverCurrentCnt =0;
					LedLightTime =BKLTIME;
					BKLED_ON();
					ErrorFlag = SHORT_ERR;
					WritePara(ALM_STATUS_ADDR,(unsigned int*)(&ErrorFlag),sizeof(ErrorFlag));
					StopWork();
					Work_Status  = Error_stat;
					LedLightTime = BACKLIGHTTIME;
					ErrDly =CONSTERRDLYTIME;
					BELLON(10,ERRBUZZTIME);
				}
			}
			else{
				UnderCurrentCnt =0;
				OverCurrentCnt =0;
			}
		}
		else{						//���빤����ѹ18V����
			if(Current < DC24V_LOW){
				OverCurrentCnt = 0;
				if(++UnderCurrentCnt>OVERCURRTIME){
					UnderCurrentCnt =0;
					LedLightTime =BKLTIME;
					BKLED_ON();
					ErrorFlag = OPEN_ERR;
					WritePara(ALM_STATUS_ADDR,(unsigned int*)(&ErrorFlag),sizeof(ErrorFlag));
					StopWork();
					Work_Status  = Error_stat;
					LedLightTime = BACKLIGHTTIME;
					ErrDly =CONSTERRDLYTIME;
					BELLON(10,ERRBUZZTIME);
				}
			}
			else if(Current > DC24V_HIGH){
				UnderCurrentCnt = 0;
				if(++OverCurrentCnt>OVERCURRTIME){
					OverCurrentCnt =0;
					LedLightTime =BKLTIME;
					BKLED_ON();
					ErrorFlag = SHORT_ERR;
					WritePara(ALM_STATUS_ADDR,(unsigned int*)(&ErrorFlag),sizeof(ErrorFlag));
					StopWork();
					Work_Status  = Error_stat;
					LedLightTime = BACKLIGHTTIME;
					ErrDly =CONSTERRDLYTIME;
					BELLON(10,ERRBUZZTIME);
				}
			}
			else{
				UnderCurrentCnt =0;
				OverCurrentCnt =0;
			}
		}
	}
	else if(RUN_STOP_T ==0){
		UnderCurrentCnt =0;
		OverCurrentCnt=0; 
	}
}
void WorkProc(void)
{
	//1s ִ��һ��
	unsigned char ctemp;
	if(ErrorFlag || SetMode){
		WRLYOFF();
	}
	else{
		if(Force_Work_T){
			if(ForceTime<999)ForceTime++;
			WRLYON();
		}
		else{
			if(RUN_STOP_T==0){	
				WRLYOFF();
				if(WorkTime.Second){
					WorkTime.Second--;
				}
				else if(WorkTime.Minute){
					WorkTime.Second =59;
					WorkTime.Minute--;
				}
				else if(WorkTime.Hour){
					WorkTime.Second =59;
					WorkTime.Minute =59;
					WorkTime.Hour--;
				}
				else{
					StartWork();
				}
			}
			else{
				if(HandRest_T==1 && RWorkTime<960 ){
					RWorkTime++;
					WRLYON();
				}
				else if(RWorkTime<RunTime ){
					RWorkTime++;
					WRLYON();
				}
				else{
					ctemp = PSstat & PS_ERR_SHIELD;
					if(ctemp != PS_ERR_SHIELD){
						ctemp |= ~PS_ERR_SHIELD;
						ErrorFlag |= ~ctemp;
						WritePara(ALM_STATUS_ADDR,(unsigned int *)(&ErrorFlag),sizeof(ErrorFlag));
						LedLightTime =BACKLIGHTTIME;
						ErrDly =CONSTERRDLYTIME;
						BELLON(10,ERRBUZZTIME);
						WorkTimeCnt++;
						if(WorkTimeCnt>=10000)WorkTimeCnt=0;
						WritePara(WORK_CONT_ADDR,(unsigned int *)(&WorkTimeCnt),sizeof(WorkTimeCnt));
						StopWork();
						Work_Status = Error_stat;
					}
					else {
						WorkTimeCnt++;
						if(WorkTimeCnt>=10000)WorkTimeCnt=0;
						WritePara(WORK_CONT_ADDR,(unsigned int *)(&WorkTimeCnt),sizeof(WorkTimeCnt));
						StopWork();
					}
				}
			}
		}
	}
}
void StartWork(void)
{
	if(SetMode || ErrorFlag||RunTime==0)return;
	RWorkTime = 0;
	RUN_STOP_T = 1;
	WRLYON();
	Work_Status = Work_stat;
	BeepCnt =0;		//���������
	PSstat =0;
//	WorkTimeCnt++;
}

void StopWork(void)
{
	WorkTime = StopTime;
	RUN_STOP_T = 0;
	WRLYOFF();
	Work_Status =Rest_stat;
	HandRest_T =0;
	PSstat =0;
}


void ReadPara(unsigned int Addr,unsigned int *pdata,unsigned char len)
{
	unsigned char i;
	

	*pdata=(*(( uint32_t*)Addr));
	for(i=1;i<=(len/4)-1;i++){
		pdata++;
		Addr=Addr+i*4;
		*pdata =(*(( uint32_t*)Addr));
	}

}

void WritePara(unsigned int Addr,unsigned int *pdata,unsigned char len)
{
	unsigned char i;
	///< FLASHĿ����������	  
	while(Ok != Flash_SectorErase(Addr))
	{
			;
	}
	Flash_WriteWord	(Addr, *pdata);
	for(i=1;i<=(len/4)-1;i++){
		pdata++;
		Addr=Addr+i*4;
		Flash_WriteWord	(Addr, *pdata);
	}

}
//void ReadPara(unsigned int Addr,unsigned char *pdata,unsigned char len)
//{
//	unsigned char i;
//	for(i=0;i<len;i++)
//		//*pdata++=Flash_ReadByte(FLASH_DATA_START_PHYSICAL_ADDRESS+Addr+i);
//		*pdata++=(*((volatile uint32_t*)Addr+i));
//	
//}
//void WritePara(unsigned int Addr,unsigned char *pdata,unsigned char len)
//{
//	unsigned char i;
//	///< FLASHĿ����������	  
//	while(Ok != Flash_SectorErase(Addr))
//	{
//			;
//	}
//	//FLASH_Unlock(FLASH_MEMTYPE_DATA);
//	for(i=0;i<len;i++){
//		//FLASH_ProgramByte((FLASH_DATA_START_PHYSICAL_ADDRESS+Addr+i),*pdata++);
//		Flash_WriteByte(Addr, *pdata++);
//	}
//	//FLASH_Lock(FLASH_MEMTYPE_DATA);
//}

