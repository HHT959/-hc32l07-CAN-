#ifndef __MAIN_H
#define __MAIN_H

//���ϼ̵���
#define ERLYON()		Gpio_SetIO(EVB_MOTOR_PORT, EVB_MOTOR2_PIN);
#define ERLYOFF()   Gpio_ClrIO(EVB_MOTOR_PORT, EVB_MOTOR2_PIN);

// �����̵���
#define WRLYON()		Gpio_SetIO(EVB_MOTOR_PORT, EVB_MOTOR1_PIN);
#define WRLYOFF()   Gpio_ClrIO(EVB_MOTOR_PORT, EVB_MOTOR1_PIN);

#define BKLED_ON()		Gpio_SetIO(EVB_LedBK_PORT, EVB_LedBK_PIN);
#define BKLED_OFF()		Gpio_ClrIO(EVB_LedBK_PORT, EVB_LedBK_PIN);

#define FSIN()			Gpio_GetInputIO(EVB_FS_PORT, EVB_FS_PIN)
#define RSTIN()			Gpio_GetInputIO(EVB_REST_PORT, EVB_REST_PIN)

#define PS1IN()			Gpio_GetInputIO(EVB_PS_PORT, EVB_PS1_PIN)
#define PS2IN()			Gpio_GetInputIO(EVB_PS_PORT, EVB_PS2_PIN)
#define PS3IN()			Gpio_GetInputIO(EVB_PS_PORT, EVB_PS3_PIN)
#define PS4IN()			Gpio_GetInputIO(EVB_PS_PORT, EVB_PS4_PIN)
#define PS5IN()			Gpio_GetInputIO(EVB_PS_PORT, EVB_PS5_PIN)

#define ERRBUZZTIME		50
#define BUZZTIME    	20
#define MINTIME				60			//����ʱ��1����һ���Ӹ�Ϊһ��
#define MS10					10
#define SetRunTime 	 180
#define BKLTIME				20

#define FS_ERR			0x01
#define OPEN_ERR		0x02
#define SHORT_ERR		0x04
#define PS1_ERR			0x08
#define PS2_ERR			0x10
#define PS3_ERR			0x20
#define PS4_ERR			0x40
#define PS5_ERR			0x80
#define ERR_WORKTIME   (24)

#define PS_ERR_SHIELD   0x08			//0x08-0xf8

#define LOCK	0x01

#define DC18V		320

#define DC12V_LOW 	6	     	//100mA
#define DC12V_HIGH 	700	  		//12A

#define DC24V_LOW 	6		 	//100mA
#define DC24V_HIGH 	310 		//5A

#define INITWORKTIME		60
#define BACKLIGHTTIME   20

#define CONSTERRDLYTIME		600			//10����

#define OVERCURRTIME		8		//����ʱ�䣬��λ��

#define CHECK_ADDRESS		0x1E000
#define STOP_ADDRESS		0x1E200			//��ֹʱ��
#define RUN_ADDRESS			0x1E400			//����ʱ��
#define ALM_STATUS_ADDR	0x1E600			//����״̬
#define LOCK_ADDR				0x1E800			//
#define WORK_CONT_ADDR	0x1EA00			//��������   2���ֽ�

#define RUN_STOP_ADDR		0x1EC00			//����״̬��־
#define WORK_ADDRESS		0x1EE00			//�����ȴ�ʱ��

#define CONSTLOOKTIME		40


enum WORKSTATUS {Rest_stat,Work_stat,Hand_stat,Set_stat,Error_stat,Look_stat};

extern enum WORKSTATUS Work_Status;		

extern unsigned int RUN_STOP_T;
extern struct TIME StopTime;
extern struct TIME WorkTime;

extern unsigned char Force_Work_T;
extern unsigned int ForceTime;
extern unsigned int LockFlag;
extern unsigned char LookTime;
extern unsigned int RunTime;
extern unsigned int RWorkTime;
extern unsigned char beeptime;
extern unsigned char BeepCnt;
extern unsigned int WorkTimeCnt;

extern unsigned char cTimeOut;
extern unsigned char MS_TT;
extern unsigned char MS250_TT;
extern unsigned char JS10MS_T;
extern unsigned int ErrorFlag;
extern unsigned char LedLightTime;
extern unsigned char HandRest_T;
extern unsigned char bSave;
extern unsigned char PSstat;
extern unsigned char FSstat;

extern unsigned char Rec_OK;  
extern unsigned char RecBuf[8];

extern unsigned char Can_TX_Flag;

void BELLON(unsigned char Bellcnt,unsigned char Belltime);
void BELL_Prog(void);

void StartWork(void);
void StopWork(void);
void WriteInt(unsigned int addr,unsigned int dat);
unsigned int ReadInt(unsigned int addr);
void ReadPara(unsigned int Addr,unsigned int *pdata,unsigned char len);
void WritePara(unsigned int Addr,unsigned int *pdata,unsigned char len);
void WorkProc(void);
void delaynms(unsigned char dly);
void SaveSetValue(void);
void ReadSetValue(void);

#endif 
