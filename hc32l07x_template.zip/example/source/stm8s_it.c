/* Includes ------------------------------------------------------------------*/
#include "config.h"

#define BUZZ_ON()			 Gpio_SetIO(EVB_BELL_PORT, EVB_BELL_PIN);
#define BUZZ_OFF()		 Gpio_ClrIO(EVB_BELL_PORT, EVB_BELL_PIN);

uint8_t                 u8RxFlag = FALSE;

void Can_IRQHandler(void)
{
	unsigned char i;
//	if(TRUE == CAN_IrqFlgGet(CanTxPrimaryIrqFlg))
//	{
//		CAN_IrqFlgClr(CanTxPrimaryIrqFlg);
//		Can_TX_Flag = 0;
//	}
	if(TRUE == CAN_IrqFlgGet(CanRxIrqFlg))
	{
		CAN_IrqFlgClr(CanRxIrqFlg);
		//CAN_IrqCmd(CanRxIrqEn, FALSE);

		CAN_Receive(&stcRxFrame);
	
		if(stcRxFrame.StdID == 0x49A ){
			Rec_OK=1;
			for(i=0;i<8;i++){
				RecBuf[i]=stcRxFrame.Data[i];
				
			}
		}
		u8RxFlag = TRUE;
	}
}
void Tim0_IRQHandler(void)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
//	static unsigned char shift=0;
	static unsigned char mscnt=0;
	
	//unsigned char ind;
	if(TRUE == Bt_GetIntFlag(TIM0, BtUevIrq))
	{
		if(++mscnt>=MS10){
			mscnt=0;
			JS10MS_T=1;
			//GPIO_WriteReverse(GPIOE, GPIO_PIN_3);		//������
			if(cTimeOut)cTimeOut--;
			if(beeptime)beeptime--;
			if(beeptime){
				BUZZ_ON();
			}
			else{
				BUZZ_OFF();
			}
		}
		Bt_ClearIntFlag(TIM0,BtUevIrq); //�жϱ�־����
	}
}


 










